const mongoose=require('mongoose')
const schema3=new mongoose.Schema({
name:{
    type: String,
    required:true
},
tech:{
    type:String,
    required:true
},
subl:{
    type:Boolean,
    required:true,
    default:false
}
})

module.exports=mongoose.model('schema1',schema3)